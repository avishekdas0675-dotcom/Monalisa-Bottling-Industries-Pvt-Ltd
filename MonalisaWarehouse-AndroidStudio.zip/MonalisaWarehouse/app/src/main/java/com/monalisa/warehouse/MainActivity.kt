package com.monalisa.warehouse

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy=Color(0xFF0B1220); private val Blue=Color(0xFF2563EB); private val Bg=Color(0xFFF4F7FB)
class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{WarehouseApp()}} }
@Composable fun WarehouseApp(){
 var screen by remember{mutableStateOf("Dashboard")}
 MaterialTheme(colorScheme=lightColorScheme(primary=Blue,background=Bg)){Scaffold(bottomBar={NavigationBar{listOf("Home","Stock","Dispatch","Reports").forEach{n->NavigationBarItem(selected=screen==n,onClick={screen=n},icon={Text(if(n=="Home")"⌂" else if(n=="Stock")"▣" else if(n=="Dispatch")"⇧" else"▤",fontSize=20.sp)},label={Text(n)})}}}){p->Box(Modifier.padding(p)){when(screen){"Home","Dashboard"->Dashboard{onNav={screen=it}};"Stock"->Stock();"Dispatch"->Dispatch();else->Reports()}}}}
}
@Composable fun Header(title:String,sub:String){Column(Modifier.fillMaxWidth().background(Navy).padding(20.dp)){Text(title,color=Color.White,fontSize=25.sp,fontWeight=FontWeight.Bold);Text(sub,color=Color(0xFFB9C4D6),fontSize=13.sp)}}
@Composable fun Dashboard(onNav:(String)->Unit){Column(Modifier.fillMaxSize().background(Bg)){Header("MONALISA WAREHOUSE","Coochbehar • 27 Sep 2026");Column(Modifier.padding(16.dp)){Text("Today's overview",fontSize=18.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("600 ml","12,450 CS");Stat("300 ml","5,280 CS")};Spacer(Modifier.height(10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("Dispatch","500 CS");Stat("Pending TP","08")};Spacer(Modifier.height(18.dp));Text("Quick actions",fontSize=18.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));val acts=listOf("Receive Material","Dispatch","Stock","OFS / TP","Expenses","Documents","Contractor","Reports");LazyVerticalGrid(columns=GridCells.Fixed(2),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(acts){a->Button(onClick={onNav(if(a=="Stock")"Stock" else if(a=="Dispatch")"Dispatch" else if(a=="Reports")"Reports" else "Dashboard")},shape=RoundedCornerShape(16.dp),modifier=Modifier.height(70.dp)){Text(a,fontSize=14.sp)}}}}}}
@Composable fun Stat(a:String,b:String){Card(Modifier.weight(1f),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(14.dp)){Text(a,color=Color.Gray,fontSize=12.sp);Text(b,fontSize=20.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun Stock(){Column(Modifier.fillMaxSize().background(Bg)){Header("Stock","Live warehouse balance");Column(Modifier.padding(16.dp)){Text("Product stock",fontSize=20.sp,fontWeight=FontWeight.Bold);StockRow("Monalisa Gold 600 ml","12,450 CS","OFC 615–620 ml");StockRow("Monalisa Gold 300 ml","5,280 CS","OFC 315–320 ml");Spacer(Modifier.height(15.dp));Text("Warehouse",fontSize=18.sp,fontWeight=FontWeight.Bold);Text("Coochbehar FL Warehouse",color=Color.Gray)}}}
@Composable fun StockRow(name:String,qty:String,detail:String){Card(Modifier.fillMaxWidth().padding(vertical=6.dp),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(16.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(name,fontWeight=FontWeight.Bold);Text(detail,color=Color.Gray,fontSize=12.sp)}Text(qty,fontWeight=FontWeight.Bold,color=Blue)}}}
@Composable fun Dispatch(){var saved by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().background(Bg)){Header("Dispatch","Create a dispatch entry");Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Field("OFS No.");Field("TP No.");Field("Vehicle No.");Field("Product / Quantity");Field("Party / Warehouse");Button(onClick={saved=true},modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(14.dp)){Text(if(saved)"✓ Dispatch Saved" else "Save Dispatch",fontSize=16.sp,fontWeight=FontWeight.Bold)}if(saved)Text("Dispatch entry saved successfully.",color=Color(0xFF15803D),fontWeight=FontWeight.Bold)}}}
@Composable fun Field(label:String){OutlinedTextField(value="",onValueChange={},label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true)}
@Composable fun Reports(){Column(Modifier.fillMaxSize().background(Bg)){Header("Reports","Warehouse performance");Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){listOf("Daily Stock Report","Dispatch Report","Receipt Report","OFS / TP Pending Report","Expense Report","Monthly Summary").forEach{Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(18.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(it,fontWeight=FontWeight.Bold);Text("›",fontSize=22.sp,color=Blue)}}}}}}
